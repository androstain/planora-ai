import { describe, it, expect } from "vitest";
import { generateId, cn } from "@/lib/utils";

describe("Utils Library", () => {
  it("generateId generates IDs with specified prefix", () => {
    const id1 = generateId("bi");
    const id2 = generateId("event");
    expect(id1.startsWith("bi_")).toBe(true);
    expect(id2.startsWith("event_")).toBe(true);
  });

  it("generateId generates distinct IDs across successive invocations", () => {
    const ids = new Set<string>();
    for (let i = 0; i < 50; i++) {
      ids.add(generateId("item"));
    }
    expect(ids.size).toBe(50);
  });

  it("generateId uses default prefix if none provided", () => {
    const id = generateId();
    expect(id.startsWith("id_")).toBe(true);
  });

  it("cn merges class names properly with tailwind-merge", () => {
    expect(cn("px-2", "py-1")).toBe("px-2 py-1");
    expect(cn("px-2", "px-4")).toBe("px-4");
    expect(cn("text-red-500", undefined, false && "text-blue-500")).toBe("text-red-500");
  });
});

